# 🐺 银狼数据安全平台

## Silver Wolf Security Platform

基于 ELK 技术栈的社工库数据管理与分析平台。支持多种数据格式导入、全文搜索、数据分析、号码归属地查询，以及 AI 辅助分析。

> 主题色: `#6A79E3` | Fluent Design 风格 | 支持暗黑模式

---

## 功能特性

- **全文搜索** — 基于 Elasticsearch 的高性能多字段搜索
- **数据分析** — 来源分布、泄露时间线、邮箱域名统计等可视化分析
- **多格式导入** — 支持 TXT/CSV/SQL/XLS/MDB 等多种数据格式
- **自定义格式模板** — 可视化配置字段映射和分隔符
- **号码归属地查询** — 手机号归属地、身份证地区解析（含港澳台）
- **插件系统** — 前后端统一的轻量级插件架构
- **AI 分析** — 集成 LLM 进行邮箱聚类、密码模式分析、风险评估
- **暗黑模式** — 完整的明暗主题切换支持
- **Kibana 仪表盘** — 开箱即用的数据可视化仪表盘

---

## 技术栈

| 层级 | 技术 |
|------|------|
| 前端 | Vue.js 2.x + Vuex + Vue Router + ECharts |
| 后端 | Python 3.9+ + Flask |
| 搜索引擎 | Elasticsearch 7.15 |
| 数据管道 | Logstash 7.15 |
| 可视化 | Kibana 7.15 |
| 缓存 | Redis 6.2 |
| 部署 | Docker + Docker Compose + Nginx |

---

## 快速开始

### 环境要求

- Docker 20.10+
- Docker Compose 1.29+
- 4GB+ 可用内存
- 10GB+ 磁盘空间

### 一键安装

```bash
git clone <repo-url> silver-wolf-platform
cd silver-wolf-platform
cp .env.example .env  # 编辑配置
./install.sh
```

安装完成后访问:

| 服务 | 地址 |
|------|------|
| 前端界面 | http://localhost:8080 |
| 后端 API | http://localhost:5000 |
| Kibana | http://localhost:5601 |
| Elasticsearch | http://localhost:9200 |

### 手动启动

```bash
docker-compose up -d          # 启动所有服务
docker-compose logs -f        # 查看日志
docker-compose down           # 停止服务
```

---

## 数据导入

### 方式一：Web 界面导入

1. 访问 **数据导入** 页面
2. 选择或创建格式模板
3. 上传数据文件
4. 确认设置并开始导入

### 方式二：命令行导入

```bash
# 使用分块导入工具（支持100MB+大文件）
python backend/chunk_import.py data/example.txt \
  --split "----" \
  --fields "email,password" \
  --source "示例数据" \
  --batch-size 5000 \
  --chunk-size 100
```

### 方式三：Logstash 管道

将数据文件放入 `data/` 目录，Logstash 自动检测并导入。

### 支持的数据格式

TXT, CSV, SQL, BAK, MDB, FRM/MYD/MYI, LOG, XLS/XLSX

---

## 项目结构

```
silver-wolf-platform/
├── frontend/               # Vue.js 前端
│   ├── src/
│   │   ├── components/     # 组件（Search, Analysis, Login...）
│   │   ├── views/          # 页面（Home, Import, Tools, Admin）
│   │   ├── plugins/        # 前端插件系统
│   │   ├── router/         # 路由配置
│   │   ├── store/          # Vuex 状态管理
│   │   └── styles/         # 主题样式
│   ├── public/
│   └── Dockerfile
├── backend/                # Flask 后端
│   ├── api/                # API 路由
│   │   ├── tools/          # 工具 API（手机号/身份证查询）
│   │   ├── llm.py          # LLM 分析 API
│   │   └── format_templates.py
│   ├── plugins/            # 后端插件系统
│   ├── utils/              # 工具类（ES客户端、数据处理器）
│   ├── data/               # 数据文件（归属地、行政区划）
│   └── Dockerfile
├── logstash/               # Logstash 配置和管道
├── kibana/                 # Kibana 仪表盘配置
├── tools/                  # 数据处理工具脚本
├── configs/                # 运行时配置
├── data/                   # 原始数据文件目录
├── docker-compose.yml
├── .env
├── install.sh
├── run.sh
└── uninstall.sh
```

---

## 插件开发

### 后端插件

```python
from plugins.core.base import PluginBase

class Plugin(PluginBase):
    id = 'my_plugin'
    name = '我的插件'
    version = '1.0.0'
    
    def register_routes(self, bp):
        @bp.route('/hello')
        def hello():
            return {'message': 'Hello from plugin!'}
```

将插件放入 `backend/plugins/modules/my_plugin/` 目录，系统自动发现和加载。

### 前端插件

```javascript
import PluginBase from '@/plugins/core/base'

export default class MyPlugin extends PluginBase {
  constructor() {
    super({
      id: 'my_plugin',
      name: '我的插件',
      version: '1.0.0'
    })
    this.routes = [{ path: '/my-plugin', component: MyComponent }]
  }
}
```

---

## 环境变量

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `MODE` | 运行模式 (local/remote) | local |
| `ES_HOST` | ES 主机 | elasticsearch |
| `ES_PORT` | ES 端口 | 9200 |
| `ES_INDEX` | 索引名 | socialdb |
| `STORAGE_MODE` | 存储模式 (reference/duplicate) | reference |
| `LLM_API_KEY` | LLM API密钥 | - |
| `LLM_BASE_URL` | LLM API地址 | https://api.openai.com/v1 |

---

## API 文档

### 搜索

```
GET /api/find/{field}/{value}?limit=10&skip=0
```

### 分析

```
GET /api/analysis/{type}  # type: source, xtime, suffix_email, create_time
```

### 号码查询

```
POST /api/tools/mobile/lookup   # { "number": "13800138000" }
POST /api/tools/idcard/lookup   # { "number": "110101199001011234" }
```

### LLM 分析

```
POST /api/llm/analyze  # { "type": "risk_report", "data": "..." }
GET  /api/llm/templates
```

---

## 许可证

MIT License

---

> 银狼数据安全平台 — 让数据安全分析更高效 🐺
